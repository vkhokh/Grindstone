import 'package:dp/models/user_profile.dart';
import 'package:dp/pages/main_page.dart';
import 'package:dp/services/user_session_storage.dart';
import 'package:dp/widgets/user_profile_form.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:dp/colors.dart';

class UserInfoPage extends StatefulWidget {
  const UserInfoPage({super.key});

  @override
  State<UserInfoPage> createState() => _UserInfoPageState();
}

class _UserInfoPageState extends State<UserInfoPage> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();

  UserGender? _selectedGender;
  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    _nameController.addListener(_refreshState);
    _heightController.addListener(_refreshState);
    _weightController.addListener(_refreshState);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _heightController.dispose();
    _weightController.dispose();
    super.dispose();
  }

  void _refreshState() {
    setState(() {});
  }

  bool get _isFormValid {
    return _nameController.text.trim().isNotEmpty &&
        _selectedGender != null &&
        double.tryParse(_heightController.text) != null &&
        double.tryParse(_weightController.text) != null;
  }

  Future<void> _saveProfile() async {
    if (!_isFormValid) return;

    setState(() => _isSaving = true);

    await UserSessionStorage.saveProfile(
      UserProfileData(
        name: _nameController.text.trim(),
        gender: _selectedGender!,
        heightCm: double.parse(_heightController.text),
        weightKg: double.parse(_weightController.text),
      ),
    );

    await UserSessionStorage.setLoggedIn(true);

    if (!mounted) return;

    /// 🔥 ПЕРЕХОД НА ГЛАВНЫЙ
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const MainPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backGroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset(
                'assets/images/icon_user.png',
                height: 140,
              ),

              const SizedBox(height: 12),

              Text(
                'Расскажите о себе',
                textAlign: TextAlign.center,
                style: GoogleFonts.barlow(
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                  color: Colors.black,
                ),
              ),

              const SizedBox(height: 10),

              Text(
                'Эти данные появятся в профиле и их можно будет изменить позже.',
                textAlign: TextAlign.center,
                style: GoogleFonts.barlow(
                  fontSize: 16,
                  color: Colors.black54,
                  fontWeight: FontWeight.w500,
                ),
              ),

              const SizedBox(height: 30),

              /// 🔥 ФОРМА БЕЗ БЕЛЫХ КАРТОЧЕК
              UserProfileForm(
                nameController: _nameController,
                heightController: _heightController,
                weightController: _weightController,
                selectedGender: _selectedGender,
                onGenderSelected: (gender) {
                  setState(() {
                    _selectedGender = gender;
                  });
                },
              ),

              const SizedBox(height: 30),

              SizedBox(
                width: 265,
                height: 60,
                child: ElevatedButton(
                  onPressed: _isFormValid && !_isSaving ? _saveProfile : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: elevatedButtonBackgroundColor,
                    foregroundColor: elevatedButtonForegroundColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: Text(
                    _isSaving ? 'Сохранение...' : 'Продолжить',
                    style: GoogleFonts.barlow(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}